
import myclient.MyClient;

class ClientConsole{
	
	public static void main(String args[]){
		MyClient.main(args);
	}
}