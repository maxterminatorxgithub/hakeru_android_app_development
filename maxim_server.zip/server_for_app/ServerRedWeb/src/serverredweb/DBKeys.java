/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serverredweb;

/**
 *
 * @author maxim.p
 */
public class DBKeys {
    
    public static final String APP_DATA_USER="app_master";
    
    public static final String APP_DATA_PASS="TzwaTqsPv0D3CVaE";
    
    
}
