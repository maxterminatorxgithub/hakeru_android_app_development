/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serverredweb;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

/**
 *
 * @author maxterminatorx
 */
public class ClientThread extends Thread{
    
    private Socket client;
    
    
    public ClientThread(Socket client){
        this.client=client;
        
    }
    
    @Override
    public void run(){
        
        try(InputStream is=client.getInputStream();
                OutputStream os=client.getOutputStream()){
            switch(is.read()){
                
                case 1:
                    os.write(returnMassages().getBytes());
                    return;
                    
                case 2:
                    byte[]data = new byte[4096];
                    is.read(data);
                    addMassage(new String(data).trim());
                    os.write("massage was accepted!".getBytes());
                    return;
                    
            }
        }catch(Exception ex){
        
        }
        
    }
    
    
    
    
    public void addMassage(String str){
        synchronized(ServerRedWeb.comments){
            ServerRedWeb.comments.add(str);
        }
    }
    
    public String returnMassages(){
        StringBuffer sb = new StringBuffer();
        synchronized(ServerRedWeb.comments){
            for(String comment:ServerRedWeb.comments){
                sb.append(comment).append('\n');
            }
        }
        return sb.toString();
    }
        
}

    
    
    
    
