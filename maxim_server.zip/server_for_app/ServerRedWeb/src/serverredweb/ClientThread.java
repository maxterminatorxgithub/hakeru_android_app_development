/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serverredweb;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.sql.SQLException;
import java.util.Date;

/**
 *
 * @author maxterminatorx
 */
public class ClientThread extends Thread{
    
    public static final byte CMD_CHECK_IS_PARENT_EXIST = 0X0A;
    public static final byte CMD_ADD_NEW_PARENT = 0X0B;
   
    public static final byte CMD_CHECK_IS_CHILD_EXIST = 0X1A;
    public static final byte CMD_ADD_NEW_CHILD = 0X1B;
   
    public static final byte CMD_CHECK_SIM_CARD = 0X2A;
    
    private Socket client;
    
    private Date connectionDate;
    
    
    public ClientThread(Socket client){
        this.client=client;
        connectionDate=new Date();
    }
    
    @Override
    public void run(){
        
        System.out.println("Log: connection detected at: "+connectionDate);
        String clientIP = client.getInetAddress().getHostAddress();
        System.out.println("Log: from ip address: "+clientIP);
        
        
        try(InputStream is=client.getInputStream();
                OutputStream os=client.getOutputStream()){
            
            
            byte[] bytes;
            
            
            switch(is.read()){
                
                    
                case CMD_CHECK_IS_PARENT_EXIST:
                    System.out.println("connected for check if parent exist.");
                    os.write(0);
                    return;
                    
                case CMD_ADD_NEW_PARENT:
                    System.out.println("connected for add new parent.");
                    bytes = new byte[19];
                    is.read(bytes);
                    os.write(addParent(new String(bytes,"utf-8"),connectionDate));
                    return;
                    
                case CMD_CHECK_IS_CHILD_EXIST:
                    System.out.println("connected for check if child exist.");
                    os.write(0);
                    return;
                    
                case CMD_ADD_NEW_CHILD:
                    System.out.println("connected for add new child.");
                    os.write(0);
                    return;
                    
                case CMD_CHECK_SIM_CARD:
                    System.out.println("connected for check sim card if exist.");
                    
                    bytes = new byte[19];
                    is.read(bytes);
                    
                    String simCard = new String(bytes,"utf-8");
                    
                    os.write(checkSimCard(simCard));
                    return;
                    
                default:
                    os.write(-1);
                
            }
            
            client.shutdownInput();
            client.shutdownOutput();
        }catch(Exception ex){
        
        }
        
    }
    
    /**
     * checkSimCard method checks if has SIM number
     * througth http://rlcellfinance system
     * 
     * @param simCard the SIM number to check if exist  
     * @return 1  - if the SIM card exist
     *         0  - if the SIM card not exist
     *         -1 - if has some error in request
     */
    
    public static byte checkSimCard(String simCard){
        
        if(ServerRedWeb.database!=null&&ServerRedWeb.database.isConnected())
            return ServerRedWeb.database.checkSimCard(simCard);
       
        System.out.println("SQL Error log: database is disconnected");
        return -1;
    }
    
    public static int addParent(String simCard,Date registration){
        if(ServerRedWeb.database!=null&&ServerRedWeb.database.isConnected()){
            synchronized(ServerRedWeb.database){
                try{
                    ServerRedWeb.database.addParent(new Parent(simCard,registration));
                    return 0;
                }catch(SQLException sqlex){
                    System.out.println("SQL Error Log Exception: "+sqlex);
                    System.out.println("SQL Error Log Massage: "+sqlex.getMessage());
                    return -1;
                }
            }
        }
        
        return -1;
    }
    
    
        
}

    
    
    
    
