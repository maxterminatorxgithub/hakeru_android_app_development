/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serverredweb;

import java.io.IOException;
import java.sql.SQLException;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

import java.sql.DriverManager;
/**
 *
 * @author maxim.p
 */
public abstract class DatabaseHandler implements DatabaseController{

    
    private Connection con;
    private Statement state;
    
    private boolean isConnected;
    
    @Override
    public void connect(String user, String password,String fullDatabaseURL)throws SQLException{
        con = DriverManager.getConnection(fullDatabaseURL, user, password);
        con.createStatement();
        
        
        isConnected = true;
    }
    
    @Override
    public void connect(String user, String password)throws SQLException{
        connect(user,password,DatabaseController.DEFAULT_MYSQL_PROTOCOL+
                              DatabaseController.DEFAULT_MYSQL_LOCALHOST+':'+
                              DatabaseController.DEFAULT_MYSQL_PORT+'/'+
                              DatabaseController.DEFAULT_MYSQL_DATABASE);
        
    }

    @Override
    public void connect() throws SQLException {
        connect("root","");
    }

    @Override
    public boolean isConnected(){
        return isConnected;
    }

    @Override
    public void close() throws SQLException {
        state.close();
        con.close();
    }
    
    
    public synchronized byte checkSimCard(String simCard){
        
        try(ResultSet res = state.executeQuery("SELECT `id` FROM `parents` WHERE `sim_card` = '"+simCard+"'");){
            if(res.getFetchSize()>0)
                return 1;
            return 0;
        }catch(SQLException sqlex){
            System.out.println("SQL Error Log Exception: "+sqlex);
            System.out.println("SQL Error Log Massage: "+sqlex.getMessage());
            return -1;
        }
        
    }
    
    /**
     * 
     * 
     * @param parentId id of the parent in database
     * @return Parent object
     */
    
    public ResultSet getParent(int parentId) throws SQLException{
        return state.executeQuery("SELECT * FROM `parents` WHERE `id` = '"+parentId+"'");
    }
    
    public void addParent(Parent p) throws SQLException{
        state.executeUpdate("INSERT INTO `parents` (`sim_card`,`registration_date`)VALUES('"+p.getSimCard()+"','"+p.getRegistredDate()+"')");
    }
    
    
    
}
