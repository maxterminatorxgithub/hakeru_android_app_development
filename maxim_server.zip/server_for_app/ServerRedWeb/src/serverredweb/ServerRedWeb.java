/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serverredweb;


import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.ServerSocket;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JFrame;
/**
 *
 * @author maxterminatorx
 */
public class ServerRedWeb {

    static ServerSocket server;
    static RedWebDB database;
    static JFrame GUI;
    static boolean showAnim;
    
    public static void main(String[] args) {
        
        
        
        int usePort = 3000;
        
        if(args.length == 1){
            try{
                usePort = Integer.valueOf(args[0]);
                if(usePort > 0X0000ffff || usePort < 0){
                    System.out.println("Port Error Format: Port must be between 0 and "+0X0000ffff);
                    usePort = 3000;
                    System.out.println("Using default Port: "+usePort);
                }
            }catch(NumberFormatException ex){
                System.out.println("Port Error Format: "+ex.getMessage());
                System.out.println("Using default Port: "+usePort);
            }
        }else{
            System.out.println("No port parameter detected using default Port: "+usePort);
        }
        
        Scanner scan = new Scanner(System.in);
        
        class LocalThread extends Thread{
            int port;
            LocalThread(int port){
                this.port=port;
            }
        }
        
        new LocalThread(usePort){
            
            @Override
            public void run(){
                startServer(port);
            }
            
        }.start();
        
        
        String command = "";
        
        while(!command.equals("exit")){
            command = scan.next();
            switch(command){
                case "gui":
                    if(GUI == null){
                        GUI = new ServerGUI();
                        System.out.println("Soviet Server Reactor GUI activated.");
                    }else if(!GUI.isVisible()){
                        GUI.setVisible(true);
                        System.out.println("Soviet Server Reactor GUI activated.");
                    }
                    else
                        System.out.println("Soviet Server Reactor GUI already running.");
                    break;
                case "+anim":
                    showAnim = true;
                    if(GUI!=null)
                        GUI.repaint();
                    System.out.println("anim ON.");
                    
                    break;
                case "-anim":
                    showAnim = false;
                    if(GUI!=null)
                        GUI.repaint();
                    System.out.println("anim OFF.");
                    
            }
        }
        
        System.out.println("Soviet Server Reactor was stopped.");
        System.exit(0);
        
    }
    
    
    
    public static void startServer(int port){
        try(ServerSocket server = new ServerSocket();
                DatabaseController database = new RedWebDB();){
            server.bind(new InetSocketAddress("RLCELL",port));
            System.out.println("Soviet Server Reactor v0.8 BETA is started run on address: "+server.getInetAddress().getHostAddress());
            System.out.println("Soviet Server Reactor v0.8 BETA is started run on port: "+server.getLocalPort());
            
            ServerRedWeb.server = server;
            
            System.out.println("SQL Log: waiting for connection to MySQL Database...");
            database.connect();
            System.out.println("SQL Log: Connection ssucceded to database.");
            ServerRedWeb.database=(RedWebDB)database;
            
            System.out.println("Server is listening.");
            while(true){
                listenToClients().start();
            }
            
            
        }catch(IOException ioex){
            System.out.println("Server Error:");
            System.out.println("IOException: "+ioex);
            System.out.println("Massage: "+ioex.getMessage());
        }catch(SQLException sqlex){
            System.out.println("SQL Error Log:");
            System.out.println("SQLException: "+sqlex);
            System.out.println("Massage: "+sqlex.getMessage());
            
            for(Throwable t:sqlex){
                System.out.println("SQL Error Log: "+t.getMessage());
            }
        }
    }
    
    
    
    public static ClientThread listenToClients()throws IOException{
        Socket client = server.accept();
        return new ClientThread(client);
    }
    
    
    
}
