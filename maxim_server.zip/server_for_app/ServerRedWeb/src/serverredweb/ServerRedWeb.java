/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serverredweb;


import java.io.IOException;
import java.net.Socket;
import java.net.ServerSocket;
import java.util.ArrayList;
/**
 *
 * @author maxterminatorx
 */
public class ServerRedWeb {

    static ServerSocket server;
    
    static ArrayList<String> comments;
    
    public static void main(String[] args) {
        
        comments = new ArrayList();
        
        try(ServerSocket server = new ServerSocket(3000);){
            System.out.println("server is started run on port: "+server.getLocalPort());
            ServerRedWeb.server = server;
            System.out.println("server is listening for clients:");
            
            while(true){
                listenToClients().start();
            }
            
            
        }catch(IOException ioex){
            System.out.println("Server Error:");
            System.out.println("Exception: "+ioex);
            System.out.println("Massage: "+ioex.getMessage());
        }
        
        
    }
    
    
    public static ClientThread listenToClients()throws IOException{
        
        Socket client = server.accept();
        return new ClientThread(client);
    }
    
}
