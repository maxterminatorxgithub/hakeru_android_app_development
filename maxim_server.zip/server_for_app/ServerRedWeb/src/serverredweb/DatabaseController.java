/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serverredweb;

import java.sql.SQLException;
import java.util.Map;
import java.io.Closeable;

/**
 *
 * @author maxim.p
 */
public interface DatabaseController extends AutoCloseable{
    
    
    String DEFAULT_MYSQL_PROTOCOL = "jdbc:mysql://";
    
    String DEFAULT_MYSQL_LOCALHOST = "localhost";
    
    String DEFAULT_MYSQL_DATABASE = "app_database";
    
    int DEFAULT_MYSQL_PORT = 3306;
    
    
    
    void connect(String user,String password,String host)throws SQLException;
    
    void connect(String user,String password)throws SQLException;
    
    void connect()throws SQLException;
    
    
    
    
    boolean isConnected();
    
    
    
    @Override
    void close() throws SQLException;
}
