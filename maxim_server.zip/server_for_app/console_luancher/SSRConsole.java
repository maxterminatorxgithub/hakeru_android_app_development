
import serverredweb.ServerRedWeb;

class SSRConsole{
	public static void main(String args[]){
		ServerRedWeb.main(args);
	}
}